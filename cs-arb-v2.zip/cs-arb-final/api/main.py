"""
CS-Arb Platform — FastAPI Backend

Endpoints:
  GET /spreads          — current profitable arbitrage opportunities
  GET /price/{item}     — price history for one item
  GET /markets          — market health status
  GET /search           — search items by name
  WS  /ws/spreads       — real-time spread updates
"""

import json
import os
import logging
from typing import Optional
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import redis
import clickhouse_connect
import asyncio

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("api")

app = FastAPI(
    title="CS-Arb Platform API",
    description="Multi-market CS2 skin arbitrage analytics",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Lock this down in production
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_redis() -> redis.Redis:
    return redis.from_url(
        os.getenv("REDIS_URL", "redis://localhost:6379"),
        decode_responses=True,
    )


def get_ch_client():
    return clickhouse_connect.get_client(
        host=os.getenv("CLICKHOUSE_HOST", "localhost"),
        port=int(os.getenv("CLICKHOUSE_PORT", "8123")),
        database=os.getenv("CLICKHOUSE_DB", "cs_arb"),
        username=os.getenv("CLICKHOUSE_USER", "admin"),
        password=os.getenv("CLICKHOUSE_PASSWORD", "admin123"),
    )


# ─── Spreads ─────────────────────────────────────────────────────────────────

@app.get("/spreads")
async def get_spreads(
    min_profit_pct: float = Query(default=3.0, ge=0, le=100),
    min_profit_usd: float = Query(default=0.10, ge=0),
    buy_market: Optional[str] = None,
    sell_market: Optional[str] = None,
    item_type: Optional[str] = None,
    max_buy_price: Optional[float] = None,
    min_liquidity: float = Query(default=0.0, ge=0, le=1),
    limit: int = Query(default=50, ge=1, le=500),
    sort_by: str = Query(default="net_profit_pct", pattern="^(net_profit_pct|net_profit_usd|liquidity_score)$"),
):
    """
    Get current profitable arbitrage spreads.
    Results are cached from the last collector run (max 10 min old).
    """
    r = get_redis()

    cached = r.get("spreads:latest")
    if not cached:
        raise HTTPException(
            status_code=503,
            detail="No spread data available yet. Collector may still be initializing."
        )

    spreads = json.loads(cached)

    # Apply filters
    filtered = [s for s in spreads if (
        s["net_profit_pct"] >= min_profit_pct
        and s["net_profit_usd"] >= min_profit_usd
        and s["liquidity_score"] >= min_liquidity
        and (buy_market is None or s["buy_market"] == buy_market)
        and (sell_market is None or s["sell_market"] == sell_market)
        and (item_type is None or s.get("item_type", "").lower() == item_type.lower())
        and (max_buy_price is None or s["buy_price"] <= max_buy_price)
    )]

    # Sort
    filtered.sort(key=lambda x: x.get(sort_by, 0), reverse=True)

    last_update = r.get("spreads:last_update")

    return {
        "total": len(filtered),
        "last_updated": last_update,
        "data": filtered[:limit],
    }


# ─── Price History ────────────────────────────────────────────────────────────

@app.get("/price/{market_hash_name:path}")
async def get_price_history(
    market_hash_name: str,
    market: Optional[str] = None,
    hours: int = Query(default=168, ge=1, le=8760),  # 1h to 1year
    granularity: str = Query(default="1h", pattern="^(5m|1h|1d)$"),
):
    """
    Price history for a specific item.
    Returns OHLCV candles.
    """
    ch = get_ch_client()

    if granularity == "5m":
        trunc = "toStartOfFiveMinutes(ts)"
    elif granularity == "1d":
        trunc = "toStartOfDay(ts)"
    else:
        trunc = "toStartOfHour(ts)"

    market_filter = f"AND market = '{market}'" if market else ""

    result = ch.query(f"""
        SELECT
            {trunc} AS period,
            market,
            min(price_usd) AS low,
            max(price_usd) AS high,
            argMin(price_usd, ts) AS open,
            argMax(price_usd, ts) AS close,
            sum(listing_count) AS volume
        FROM cs_arb.price_ticks
        WHERE
            market_hash_name = %(name)s
            AND ts >= now() - INTERVAL %(hours)s HOUR
            {market_filter}
        GROUP BY period, market
        ORDER BY period ASC, market
    """, parameters={"name": market_hash_name, "hours": hours})

    candles = []
    for row in result.result_rows:
        candles.append({
            "t": row[0].isoformat() if hasattr(row[0], "isoformat") else str(row[0]),
            "market": row[1],
            "low": round(row[2], 4),
            "high": round(row[3], 4),
            "open": round(row[4], 4),
            "close": round(row[5], 4),
            "volume": int(row[6]),
        })

    return {
        "item": market_hash_name,
        "granularity": granularity,
        "hours": hours,
        "candles": candles,
    }


# ─── Market Health ────────────────────────────────────────────────────────────

@app.get("/markets")
async def get_market_status():
    """Current market collector status and item counts."""
    r = get_redis()
    ch = get_ch_client()

    markets = ["skinport", "dmarket", "csfloat", "steam", "buff", "shadowpay"]
    status = {}

    for market in markets:
        count = r.get(f"market:{market}:item_count")
        status[market] = {
            "item_count": int(count) if count else 0,
            "active": count is not None,
        }

    # Last health records per market
    health_records = []
    try:
        health = ch.query("""
            SELECT market, status, items_fetched, fetch_duration_ms, ts
            FROM cs_arb.market_health
            WHERE ts >= now() - INTERVAL 1 HOUR
            ORDER BY ts DESC
            LIMIT 20
        """)
        for row in health.result_rows:
            health_records.append({
                "market": row[0],
                "status": row[1],
                "items": row[2],
                "duration_ms": row[3],
                "ts": row[4].isoformat() if hasattr(row[4], "isoformat") else str(row[4]),
            })
    except Exception:
        pass

    return {"markets": status, "recent_health": health_records}


# ─── Search ──────────────────────────────────────────────────────────────────

@app.get("/search")
async def search_items(
    q: str = Query(min_length=2, max_length=100),
    limit: int = Query(default=20, le=100),
):
    """Search items by name (fuzzy prefix match on market_hash_name)."""
    ch = get_ch_client()

    result = ch.query("""
        SELECT DISTINCT market_hash_name, item_type, item_exterior, item_rarity
        FROM cs_arb.price_ticks
        WHERE
            market_hash_name ILIKE %(q)s
            AND ts >= now() - INTERVAL 24 HOUR
        LIMIT %(limit)s
    """, parameters={"q": f"%{q}%", "limit": limit})

    items = []
    for row in result.result_rows:
        items.append({
            "name": row[0],
            "type": row[1],
            "exterior": row[2],
            "rarity": row[3],
        })

    return {"query": q, "results": items}


# ─── WebSocket: real-time spreads ────────────────────────────────────────────

class ConnectionManager:
    def __init__(self):
        self.active: list[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        self.active.remove(ws)

    async def broadcast(self, data: str):
        dead = []
        for ws in self.active:
            try:
                await ws.send_text(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.active.remove(ws)


manager = ConnectionManager()


@app.websocket("/ws/spreads")
async def ws_spreads(websocket: WebSocket):
    """Push top spreads every 30s to connected clients."""
    await manager.connect(websocket)
    r = get_redis()
    try:
        while True:
            cached = r.get("spreads:latest")
            if cached:
                spreads = json.loads(cached)[:20]
                await websocket.send_json({
                    "type": "spreads_update",
                    "data": spreads,
                    "ts": datetime.now(tz=timezone.utc).isoformat(),
                })
            await asyncio.sleep(30)
    except WebSocketDisconnect:
        manager.disconnect(websocket)


# ─── Portfolio ───────────────────────────────────────────────────────────────

@app.get("/portfolio/{user_id}")
async def get_portfolio(user_id: str):
    """Get user portfolio with current P&L."""
    import asyncpg
    r = get_redis()

    try:
        pg = await asyncpg.connect(os.getenv("POSTGRES_URL"))
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"DB unavailable: {e}")

    # Quick mock for demo — replace with PortfolioService in production
    positions_raw = await pg.fetch(
        "SELECT * FROM positions WHERE user_id=$1 AND NOT closed ORDER BY buy_date DESC",
        user_id
    )
    await pg.close()

    positions = []
    for row in positions_raw:
        current_price = float(r.get(f"price:{row['market_hash_name']}:best") or 0)
        cost = float(row["cost_basis_usd"])
        pnl = (current_price - cost) * row["quantity"] if current_price else 0
        pnl_pct = (current_price - cost) / cost * 100 if current_price and cost else 0

        positions.append({
            "id": row["id"],
            "item": row["market_hash_name"],
            "quantity": row["quantity"],
            "cost_basis": float(row["cost_basis_usd"]),
            "current_price": current_price,
            "unrealized_pnl_usd": round(pnl, 2),
            "unrealized_pnl_pct": round(pnl_pct, 1),
            "buy_date": row["buy_date"].isoformat(),
            "buy_market": row["buy_market"] or "",
        })

    total_cost = sum(p["cost_basis"] * p["quantity"] for p in positions)
    total_value = sum(p["current_price"] * p["quantity"] for p in positions)
    total_pnl = total_value - total_cost
    total_pnl_pct = total_pnl / total_cost * 100 if total_cost else 0

    return {
        "user_id": user_id,
        "summary": {
            "total_cost_usd": round(total_cost, 2),
            "total_value_usd": round(total_value, 2),
            "unrealized_pnl_usd": round(total_pnl, 2),
            "unrealized_pnl_pct": round(total_pnl_pct, 1),
            "positions": len(positions),
        },
        "positions": positions,
    }


@app.post("/portfolio/{user_id}/add")
async def add_position(
    user_id: str,
    item: str = Query(...),
    cost_basis: float = Query(..., gt=0),
    quantity: int = Query(default=1, ge=1),
    buy_market: str = Query(default=""),
    notes: str = Query(default=""),
):
    """Add a new position to portfolio."""
    import asyncpg
    pg = await asyncpg.connect(os.getenv("POSTGRES_URL"))

    try:
        row = await pg.fetchrow("""
            INSERT INTO positions
            (user_id, market_hash_name, quantity, cost_basis_usd,
             total_cost_usd, buy_market, notes)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id
        """, user_id, item, quantity, cost_basis, cost_basis * quantity, buy_market, notes)
    finally:
        await pg.close()

    return {"status": "added", "position_id": row["id"]}


# ─── Backtesting ──────────────────────────────────────────────────────────────

@app.post("/backtest")
async def run_backtest(
    start: str = Query(default="2024-01-01"),
    end: str = Query(default="2024-12-31"),
    initial_capital: float = Query(default=1000.0, gt=0),
    min_profit_pct: float = Query(default=5.0, ge=0),
    step_hours: int = Query(default=4, ge=1, le=24),
):
    """
    Run a backtest of the SimpleSpread strategy.
    Returns performance metrics and equity curve.
    Note: requires at least `end - start` of historical data in ClickHouse.
    """
    import sys, os
    sys.path.insert(0, "/app")

    try:
        from backtesting import BacktestEngine, SimpleSpreadStrategy
    except ImportError:
        raise HTTPException(status_code=501, detail="Backtesting module not available in API container")

    ch = get_ch_client()
    strategy = SimpleSpreadStrategy(min_profit_pct=min_profit_pct)
    engine = BacktestEngine(ch)

    try:
        result = engine.run(
            strategy=strategy,
            start=start,
            end=end,
            initial_capital=initial_capital,
            step_hours=step_hours,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Backtest failed: {e}")

    return result.summary()


# ─── Alerts ──────────────────────────────────────────────────────────────────

@app.get("/alerts")
async def get_recent_alerts(limit: int = Query(default=50, le=200)):
    """Get recent alerts from Redis."""
    r = get_redis()
    raw = r.zrevrange("alerts:recent", 0, limit - 1)
    alerts = []
    for item in raw:
        try:
            alerts.append(json.loads(item))
        except Exception:
            pass
    return {"alerts": alerts, "count": len(alerts)}


# ─── Item analytics ───────────────────────────────────────────────────────────

@app.get("/analytics/{market_hash_name:path}")
async def get_item_analytics(
    market_hash_name: str,
    days: int = Query(default=30, ge=1, le=365),
):
    """
    Deep analytics for one item:
    - price trend across all markets
    - volatility
    - volume trend
    - best time to buy (by hour of day)
    """
    ch = get_ch_client()

    result = ch.query("""
        SELECT
            market,
            count()                         AS data_points,
            min(price_usd)                  AS price_min,
            max(price_usd)                  AS price_max,
            avg(price_usd)                  AS price_avg,
            stddevPop(price_usd)            AS price_std,
            sum(listing_count)              AS total_volume,
            -- First and last prices for trend
            argMin(price_usd, ts)           AS price_first,
            argMax(price_usd, ts)           AS price_last
        FROM cs_arb.price_ticks
        WHERE
            market_hash_name = %(name)s
            AND ts >= now() - INTERVAL %(days)s DAY
        GROUP BY market
    """, parameters={"name": market_hash_name, "days": days})

    market_stats = []
    for row in result.result_rows:
        market, points, mn, mx, avg, std, vol, first, last = row
        trend_pct = (last - first) / first * 100 if first else 0
        market_stats.append({
            "market": market,
            "price_min": round(mn, 4),
            "price_max": round(mx, 4),
            "price_avg": round(avg, 4),
            "price_std": round(std, 4),
            "volatility_pct": round(std / avg * 100, 2) if avg else 0,
            "volume_30d": int(vol),
            "trend_pct": round(trend_pct, 1),
            "price_first": round(first, 4),
            "price_last": round(last, 4),
        })

    return {
        "item": market_hash_name,
        "period_days": days,
        "markets": market_stats,
    }


# ─── Health ──────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {"status": "ok", "ts": datetime.now(tz=timezone.utc).isoformat()}
