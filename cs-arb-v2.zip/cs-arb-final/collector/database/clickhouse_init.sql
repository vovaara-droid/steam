-- ============================================================
-- CS ARB PLATFORM — ClickHouse Schema (fixed)
-- ============================================================

CREATE TABLE IF NOT EXISTS cs_arb.price_ticks
(
    ts              DateTime64(3, 'UTC'),
    market          LowCardinality(String),
    market_hash_name String,
    price_usd       Float64,
    currency        LowCardinality(String),
    price_original  Float64,
    listing_count   UInt32,
    market_fee_pct  Float32,
    item_type       LowCardinality(String),
    item_exterior   LowCardinality(String),
    item_rarity     LowCardinality(String),
    float_value     Nullable(Float32),
    paint_seed      Nullable(UInt16),
    sticker_count   UInt8 DEFAULT 0
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(ts)
ORDER BY (market_hash_name, market, ts)
TTL toDateTime(ts) + INTERVAL 2 YEAR
SETTINGS index_granularity = 8192;


CREATE TABLE IF NOT EXISTS cs_arb.spreads
(
    ts                  DateTime64(3, 'UTC'),
    market_hash_name    String,
    buy_market          LowCardinality(String),
    sell_market         LowCardinality(String),
    buy_price_usd       Float64,
    sell_price_usd      Float64,
    buy_fee_pct         Float32,
    sell_fee_pct        Float32,
    gross_spread_pct    Float32,
    net_profit_usd      Float64,
    net_profit_pct      Float32,
    buy_listing_count   UInt32,
    sell_listing_count  UInt32,
    liquidity_score     Float32,
    has_trade_lock      UInt8,
    avg_daily_volume_30d Float32,
    price_volatility_30d Float32,
    item_type           LowCardinality(String),
    item_exterior       LowCardinality(String)
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(ts)
ORDER BY (ts, market_hash_name, buy_market, sell_market)
TTL toDateTime(ts) + INTERVAL 90 DAY
SETTINGS index_granularity = 8192;


CREATE TABLE IF NOT EXISTS cs_arb.market_health
(
    ts                DateTime64(3, 'UTC'),
    market            LowCardinality(String),
    items_fetched     UInt32,
    fetch_duration_ms UInt32,
    error_count       UInt16,
    status            LowCardinality(String)
)
ENGINE = MergeTree()
ORDER BY (market, ts)
TTL toDateTime(ts) + INTERVAL 30 DAY;
