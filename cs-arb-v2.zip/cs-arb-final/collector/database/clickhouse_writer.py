"""
ClickHouse writer — batch inserts price ticks and spread data.
Uses clickhouse-connect (official async client).
"""

import logging
from datetime import datetime, timezone
from typing import Optional

import clickhouse_connect
from clickhouse_connect.driver.client import Client

from collectors.base import PriceTick, CollectorResult

logger = logging.getLogger(__name__)


class ClickHouseWriter:
    """
    Batch writer for price data into ClickHouse.
    Uses insert_rows for efficient batch inserts.
    """

    TICKS_TABLE = "price_ticks"
    HEALTH_TABLE = "market_health"
    BATCH_SIZE = 5000

    def __init__(
        self,
        host: str,
        port: int,
        database: str,
        username: str,
        password: str,
    ):
        self.host = host
        self.port = port
        self.database = database
        self.username = username
        self.password = password
        self._client: Optional[Client] = None

    def connect(self):
        """Create synchronous ClickHouse connection."""
        self._client = clickhouse_connect.get_client(
            host=self.host,
            port=self.port,
            database=self.database,
            username=self.username,
            password=self.password,
            settings={"async_insert": 1, "wait_for_async_insert": 0},
        )
        logger.info(f"Connected to ClickHouse at {self.host}:{self.port}")

    @property
    def client(self) -> Client:
        if not self._client:
            self.connect()
        return self._client

    def write_ticks(self, ticks: list[PriceTick], ts: Optional[datetime] = None) -> int:
        """
        Write a batch of PriceTicks to ClickHouse.
        Returns number of rows written.
        """
        if not ticks:
            return 0

        ts = ts or datetime.now(tz=timezone.utc)

        rows = []
        for t in ticks:
            rows.append([
                ts,
                t.market,
                t.market_hash_name,
                t.price_usd,
                t.currency,
                t.price_original,
                t.listing_count,
                t.market_fee_pct,
                t.item_type,
                t.item_exterior,
                t.item_rarity,
                t.float_value,
                t.paint_seed,
                t.sticker_count,
            ])

        column_names = [
            "ts", "market", "market_hash_name", "price_usd",
            "currency", "price_original", "listing_count", "market_fee_pct",
            "item_type", "item_exterior", "item_rarity",
            "float_value", "paint_seed", "sticker_count",
        ]

        # Write in batches to avoid OOM on large datasets
        written = 0
        for i in range(0, len(rows), self.BATCH_SIZE):
            batch = rows[i:i + self.BATCH_SIZE]
            self.client.insert(
                self.TICKS_TABLE,
                batch,
                column_names=column_names,
            )
            written += len(batch)
            logger.debug(f"Wrote batch {i//self.BATCH_SIZE + 1}: {len(batch)} rows")

        return written

    def write_health(self, result: CollectorResult, ts: Optional[datetime] = None):
        """Record collector health/performance data."""
        ts = ts or datetime.now(tz=timezone.utc)

        self.client.insert(
            self.HEALTH_TABLE,
            [[ts, result.market, len(result.ticks), result.duration_ms,
              result.error_count, result.status]],
            column_names=["ts", "market", "items_fetched",
                          "fetch_duration_ms", "error_count", "status"],
        )

    def get_latest_counts(self) -> dict:
        """Quick diagnostic — how many items per market in last hour."""
        result = self.client.query("""
            SELECT market, count() as items, max(ts) as last_seen
            FROM price_ticks
            WHERE ts >= now() - INTERVAL 1 HOUR
            GROUP BY market
            ORDER BY market
        """)
        return {
            row[0]: {"items": row[1], "last_seen": row[2]}
            for row in result.result_rows
        }

    def health_check(self) -> bool:
        """Verify connection is alive."""
        try:
            self.client.ping()
            return True
        except Exception as e:
            logger.error(f"ClickHouse health check failed: {e}")
            return False
