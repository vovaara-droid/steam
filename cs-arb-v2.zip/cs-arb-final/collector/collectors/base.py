"""
Base collector — abstract class for all market collectors.
Handles: rate limiting, retries, proxy rotation, error tracking.
"""

import asyncio
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional
import httpx

logger = logging.getLogger(__name__)


@dataclass
class PriceTick:
    """Normalized price record — one listing on one market."""
    market_hash_name: str
    market: str
    price_usd: float
    currency: str
    price_original: float
    listing_count: int
    market_fee_pct: float
    item_type: str = ""
    item_exterior: str = ""
    item_rarity: str = ""
    float_value: Optional[float] = None
    paint_seed: Optional[int] = None
    sticker_count: int = 0


@dataclass
class CollectorResult:
    """Result of one collection run."""
    market: str
    ticks: list[PriceTick]
    duration_ms: int
    error_count: int
    status: str  # 'ok' | 'partial' | 'error'
    error_message: str = ""


class RateLimiter:
    """Token bucket rate limiter."""

    def __init__(self, calls_per_second: float):
        self.calls_per_second = calls_per_second
        self._min_interval = 1.0 / calls_per_second
        self._last_call = 0.0

    async def acquire(self):
        now = time.monotonic()
        elapsed = now - self._last_call
        if elapsed < self._min_interval:
            await asyncio.sleep(self._min_interval - elapsed)
        self._last_call = time.monotonic()


class BaseCollector(ABC):
    """
    Abstract base for all market price collectors.

    Subclasses must implement:
        - market_name (property)
        - market_fee_pct (property)
        - fetch_prices() -> list[PriceTick]
    """

    MAX_RETRIES = 3
    RETRY_BACKOFF_BASE = 2.0  # exponential backoff seconds

    def __init__(
        self,
        rate_limit_rps: float = 1.0,
        timeout_sec: float = 30.0,
        proxies: Optional[list[str]] = None,
    ):
        self._rate_limiter = RateLimiter(rate_limit_rps)
        self._timeout = timeout_sec
        self._proxies = proxies or []
        self._proxy_index = 0
        self._client: Optional[httpx.AsyncClient] = None

    @property
    @abstractmethod
    def market_name(self) -> str:
        """Market identifier: 'skinport', 'dmarket', etc."""
        ...

    @property
    @abstractmethod
    def market_fee_pct(self) -> float:
        """Default market seller fee in %."""
        ...

    @abstractmethod
    async def fetch_prices(self) -> list[PriceTick]:
        """Fetch current prices from the market. Returns normalized PriceTick list."""
        ...

    async def collect(self) -> CollectorResult:
        """Run a full collection cycle with timing and error handling."""
        start = time.monotonic()
        error_count = 0
        ticks = []
        status = "ok"
        error_message = ""

        try:
            ticks = await self._fetch_with_retry()
            logger.info(f"[{self.market_name}] Collected {len(ticks)} items")
        except Exception as e:
            status = "error"
            error_message = str(e)
            error_count += 1
            logger.error(f"[{self.market_name}] Collection failed: {e}")

        duration_ms = int((time.monotonic() - start) * 1000)

        return CollectorResult(
            market=self.market_name,
            ticks=ticks,
            duration_ms=duration_ms,
            error_count=error_count,
            status=status,
            error_message=error_message,
        )

    async def _fetch_with_retry(self) -> list[PriceTick]:
        """Retry wrapper with exponential backoff."""
        last_exc = None
        for attempt in range(self.MAX_RETRIES):
            try:
                await self._rate_limiter.acquire()
                return await self.fetch_prices()
            except (httpx.HTTPStatusError, httpx.RequestError) as e:
                last_exc = e
                wait = self.RETRY_BACKOFF_BASE ** attempt
                logger.warning(
                    f"[{self.market_name}] Attempt {attempt + 1} failed: {e}. "
                    f"Retrying in {wait:.1f}s"
                )
                await asyncio.sleep(wait)
                self._rotate_proxy()
        raise last_exc

    def _rotate_proxy(self):
        if self._proxies:
            self._proxy_index = (self._proxy_index + 1) % len(self._proxies)

    def _current_proxy(self) -> Optional[str]:
        if self._proxies:
            return self._proxies[self._proxy_index]
        return None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create HTTP client, cycling proxy if configured."""
        proxy = self._current_proxy()
        return httpx.AsyncClient(
            timeout=self._timeout,
            proxy=proxy,
            headers={
                "User-Agent": "Mozilla/5.0 (compatible; CS-Arb-Bot/1.0)",
                "Accept": "application/json",
            },
            follow_redirects=True,
        )

    async def get(self, url: str, **kwargs) -> httpx.Response:
        """HTTP GET with rate limiting."""
        await self._rate_limiter.acquire()
        async with await self._get_client() as client:
            response = await client.get(url, **kwargs)
            response.raise_for_status()
            return response
