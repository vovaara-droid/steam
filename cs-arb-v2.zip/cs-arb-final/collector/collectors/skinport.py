import logging
import httpx
import gzip
import json
from typing import Optional
from .base import BaseCollector, PriceTick

logger = logging.getLogger(__name__)

CATEGORY_MAP = {
    "Rifle": "Rifle", "Pistol": "Pistol", "SMG": "SMG",
    "Shotgun": "Shotgun", "Sniper Rifle": "Sniper Rifle",
    "Knife": "Knife", "Gloves": "Gloves", "Agent": "Agent",
    "Sticker": "Sticker", "Case": "Case", "Key": "Key",
}

SKINPORT_HEADERS = {
    "Accept": "application/json, text/plain, */*",
    "Accept-Encoding": "gzip, deflate, br",
    "Accept-Language": "en-US,en;q=0.9",
    "Cache-Control": "no-cache",
    "Origin": "https://skinport.com",
    "Pragma": "no-cache",
    "Referer": "https://skinport.com/",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-site",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
}


class SkinportCollector(BaseCollector):
    API_URL = "https://api.skinport.com/v1/items"

    def __init__(self, currency: str = "USD", **kwargs):
        super().__init__(rate_limit_rps=0.15, **kwargs)
        self.currency = currency

    @property
    def market_name(self) -> str:
        return "skinport"

    @property
    def market_fee_pct(self) -> float:
        return 12.0

    async def fetch_prices(self) -> list[PriceTick]:
        # Use own client to avoid base class header conflicts with Skinport
        await self._rate_limiter.acquire()
        async with httpx.AsyncClient(
            headers=SKINPORT_HEADERS,
            timeout=30.0,
            follow_redirects=True,
        ) as client:
            response = await client.get(
                self.API_URL,
                params={"app_id": 730, "currency": self.currency},
            )
            response.raise_for_status()

        raw = response.content
        # Handle gzip-compressed response
        if raw[:2] == b'\x1f\x8b':
            raw = gzip.decompress(raw)

        items = json.loads(raw)
        ticks = []
        for item in items:
            tick = self._parse_item(item)
            if tick is not None:
                ticks.append(tick)
        logger.info(f"[skinport] Parsed {len(ticks)} / {len(items)} items")
        return ticks

    def _parse_item(self, item: dict) -> Optional[PriceTick]:
        try:
            quantity = item.get("quantity", 0)
            if quantity == 0:
                return None
            min_price = item.get("min_price")
            if min_price is None:
                return None
            price_usd = float(min_price)
            if price_usd <= 0:
                return None
            name = item.get("market_hash_name", "")
            if not name:
                return None
            item_type = CATEGORY_MAP.get(item.get("category", ""), item.get("category", ""))
            return PriceTick(
                market_hash_name=name,
                market=self.market_name,
                price_usd=price_usd,
                currency=self.currency,
                price_original=float(min_price),
                listing_count=item.get("quantity", 1),
                market_fee_pct=15.0 if price_usd < 1000 else 12.0,
                item_type=item_type,
                item_exterior=item.get("exterior") or "",
                item_rarity=item.get("rarity", ""),
            )
        except (KeyError, TypeError, ValueError) as e:
            logger.debug(f"[skinport] Failed: {e}")
            return None
