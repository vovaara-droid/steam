"""
DMarket Collector

DMarket has a public REST API for market prices.
Public endpoint (no auth for read-only aggregated data):
  GET https://api.dmarket.com/exchange/v1/market/items

Rate limit: ~10-20 req/min
Docs: https://docs.dmarket.com/
"""

import logging
from typing import Optional

from .base import BaseCollector, PriceTick

logger = logging.getLogger(__name__)


class DMarketCollector(BaseCollector):
    """
    Fetches CS2 prices from DMarket via paginated public API.
    DMarket takes 2-7% fee depending on price tier.
    """

    API_URL = "https://api.dmarket.com/exchange/v1/market/items"
    DEFAULT_FEE = 5.0  # ~5% average, varies
    PAGE_SIZE = 100
    MAX_PAGES = 200  # Safety limit; DMarket has ~50k+ listings

    def __init__(self, **kwargs):
        super().__init__(rate_limit_rps=0.33, **kwargs)  # ~1 req per 3 sec

    @property
    def market_name(self) -> str:
        return "dmarket"

    @property
    def market_fee_pct(self) -> float:
        return self.DEFAULT_FEE

    async def fetch_prices(self) -> list[PriceTick]:
        """Paginate through all DMarket CS2 listings."""
        ticks = []
        cursor = None
        page = 0

        while page < self.MAX_PAGES:
            batch, cursor = await self._fetch_page(cursor)
            ticks.extend(batch)

            if not cursor:
                break  # No more pages

            page += 1
            logger.debug(f"[dmarket] Fetched page {page}, total items: {len(ticks)}")

        return ticks

    async def _fetch_page(self, cursor: Optional[str]) -> tuple[list[PriceTick], Optional[str]]:
        """Fetch a single page from DMarket."""
        params = {
            "gameId": "a8db",  # CS2 game ID on DMarket
            "limit": self.PAGE_SIZE,
            "orderBy": "price",
            "orderDir": "asc",
            "currency": "USD",
        }

        if cursor:
            params["cursor"] = cursor

        resp = await self.get(self.API_URL, params=params)
        data = resp.json()

        items = data.get("objects", [])
        next_cursor = data.get("cursor")

        ticks = []
        for item in items:
            tick = self._parse_item(item)
            if tick:
                ticks.append(tick)

        return ticks, next_cursor if items else None

    def _parse_item(self, item: dict) -> Optional[PriceTick]:
        try:
            title = item.get("title", "")
            if not title:
                return None

            # DMarket price is in USD cents → convert to dollars
            price_data = item.get("price", {})
            price_str = price_data.get("USD", "0")
            price_usd = float(price_str) / 100.0
            if price_usd <= 0:
                return None

            extra = item.get("extra", {})
            item_type = extra.get("itemType", extra.get("category", ""))
            exterior = extra.get("exterior", "")

            return PriceTick(
                market_hash_name=title,
                market=self.market_name,
                price_usd=price_usd,
                currency="USD",
                price_original=price_usd,
                listing_count=1,  # DMarket lists individual items, not aggregated
                market_fee_pct=self._get_fee(price_usd),
                item_type=item_type,
                item_exterior=exterior,
                item_rarity=extra.get("quality", ""),
            )

        except (KeyError, TypeError, ValueError) as e:
            logger.debug(f"[dmarket] Parse error: {e}")
            return None

    def _get_fee(self, price_usd: float) -> float:
        """DMarket fee tiers."""
        if price_usd < 0.10:
            return 0.0
        elif price_usd < 10.0:
            return 7.0
        elif price_usd < 100.0:
            return 5.0
        else:
            return 4.0
