"""
Steam Community Market Collector

Steam doesn't have an official "get all prices" API, but exposes:
  1. Search endpoint (paginated, up to 500 per page)
  2. Price overview per item (1 req/item — too slow for bulk)

Strategy:
  - Use the search endpoint to get all CS2 listings
  - Parse result count, name, min_price, quantity
  - Steam takes 15% total (5% platform + 10% Valve game fee for CS2)

⚠️  Rate limit: Steam blocks aggressive crawlers.
    We use very conservative limits: 1 req/3s, back off on 429.
    Use only public endpoints, no Steam account required.
"""

import logging
import asyncio
from typing import Optional

from .base import BaseCollector, PriceTick

logger = logging.getLogger(__name__)

# Steam CS2 appid
CS2_APP_ID = 730

# Steam total fee breakdown:
# - Valve takes 5% platform fee
# - CS2 game fee: 10%
# - Total seller receives: 85% of buyer price (buyer pays price, seller gets price / 1.15 * 0.85)
# More precisely: sell_price = list_price * (1 - 0.15)
STEAM_SELLER_FEE_PCT = 15.0

# Categories to iterate (speeds up search vs getting everything at once)
STEAM_SEARCH_URL = "https://steamcommunity.com/market/search/render/"


class SteamCollector(BaseCollector):
    """
    Collects CS2 market prices from Steam Community Market.

    Uses paginated search — gets all listings sorted by price.
    Very slow by design (rate limit: 1 req per 3-5 sec).
    Full crawl takes ~15-30 min for all CS2 items.
    Run on a longer interval (30-60 min).
    """

    PAGE_SIZE = 100          # Steam max is 100
    MAX_PAGES = 300          # 30,000 items max per run
    SEARCH_DELAY = 3.5       # seconds between requests — critical

    def __init__(self, **kwargs):
        # Steam is extremely rate-limit sensitive
        super().__init__(rate_limit_rps=0.28, timeout_sec=20.0, **kwargs)

    @property
    def market_name(self) -> str:
        return "steam"

    @property
    def market_fee_pct(self) -> float:
        return STEAM_SELLER_FEE_PCT

    async def fetch_prices(self) -> list[PriceTick]:
        """
        Paginate through all CS2 listings on Steam Market.

        Steam returns up to 100 items per page.
        We stop when we've gotten all results or hit MAX_PAGES.
        """
        ticks = []
        start = 0
        total_count = None

        for page in range(self.MAX_PAGES):
            batch, total_count = await self._fetch_page(start, self.PAGE_SIZE)

            if not batch:
                logger.info(f"[steam] Empty page at start={start}, stopping")
                break

            ticks.extend(batch)
            start += self.PAGE_SIZE

            logger.debug(
                f"[steam] Page {page+1}: {len(batch)} items "
                f"(total fetched: {len(ticks)}/{total_count or '?'})"
            )

            # Stop if we've collected all available items
            if total_count and len(ticks) >= total_count:
                break

            # Extra sleep between pages (on top of rate limiter)
            await asyncio.sleep(self.SEARCH_DELAY)

        logger.info(f"[steam] Finished: {len(ticks)} items collected")
        return ticks

    async def _fetch_page(
        self, start: int, count: int
    ) -> tuple[list[PriceTick], Optional[int]]:
        """Fetch one page of Steam market listings."""
        params = {
            "appid": CS2_APP_ID,
            "search_descriptions": 0,
            "sort_column": "price",
            "sort_dir": "asc",
            "start": start,
            "count": count,
            "norender": 1,
            "currency": 1,  # 1 = USD
        }

        try:
            resp = await self.get(STEAM_SEARCH_URL, params=params)
            data = resp.json()
        except Exception as e:
            logger.warning(f"[steam] Page request failed at start={start}: {e}")
            return [], None

        if not data.get("success"):
            logger.warning(f"[steam] API returned success=false at start={start}")
            return [], None

        total_count = data.get("total_count")
        results = data.get("results", [])

        ticks = []
        for item in results:
            tick = self._parse_item(item)
            if tick:
                ticks.append(tick)

        return ticks, total_count

    def _parse_item(self, item: dict) -> Optional[PriceTick]:
        try:
            name = item.get("hash_name", "")
            if not name:
                return None

            # sell_price is in cents (USD * 100)
            sell_price_cents = item.get("sell_price", 0)
            if sell_price_cents <= 0:
                return None

            price_usd = sell_price_cents / 100.0
            quantity = item.get("sell_listings", 0)

            # Extract asset description for metadata
            asset = item.get("asset_description", {})
            item_type = asset.get("type", "")
            # Steam type looks like: "Covert Rifle" → split
            parts = item_type.rsplit(" ", 1)
            rarity = parts[0] if len(parts) > 1 else ""
            item_category = parts[-1] if parts else ""

            exterior = self._extract_exterior(name)

            return PriceTick(
                market_hash_name=name,
                market=self.market_name,
                price_usd=price_usd,
                currency="USD",
                price_original=price_usd,
                listing_count=quantity,
                market_fee_pct=STEAM_SELLER_FEE_PCT,
                item_type=item_category,
                item_exterior=exterior,
                item_rarity=rarity,
            )

        except (KeyError, TypeError, ValueError) as e:
            logger.debug(f"[steam] Parse error: {e} | item={item.get('hash_name')}")
            return None

    @staticmethod
    def _extract_exterior(name: str) -> str:
        exteriors = [
            "Factory New", "Minimal Wear", "Field-Tested",
            "Well-Worn", "Battle-Scarred",
        ]
        for ext in exteriors:
            if ext in name:
                return ext
        return ""
