"""
ShadowPay Collector

ShadowPay doesn't have a proper public API.
We use their internal market endpoint (same one the browser uses).

⚠️  ShadowPay has anti-bot measures.
    Use proxies (residential preferred) for production.
    Their Cloudflare protection requires proper headers + cookies.

Fee: ShadowPay takes 5% from seller.
"""

import logging
from typing import Optional

from .base import BaseCollector, PriceTick

logger = logging.getLogger(__name__)

SHADOWPAY_FEE = 5.0

# ShadowPay internal market endpoint
SHADOWPAY_API = "https://api.shadowpay.com/api/v2/user/items/sell"


class ShadowPayCollector(BaseCollector):
    """
    ShadowPay price collector via their internal API.

    Auth via session token (obtained from browser DevTools).
    Without token: read-only public listings still accessible.
    """

    PAGE_SIZE = 100
    MAX_PAGES = 200

    def __init__(self, session_token: Optional[str] = None, **kwargs):
        super().__init__(rate_limit_rps=0.5, **kwargs)
        self.session_token = session_token

    @property
    def market_name(self) -> str:
        return "shadowpay"

    @property
    def market_fee_pct(self) -> float:
        return SHADOWPAY_FEE

    async def fetch_prices(self) -> list[PriceTick]:
        ticks = []
        offset = 0

        for page in range(self.MAX_PAGES):
            batch = await self._fetch_page(offset)
            if not batch:
                break
            ticks.extend(batch)
            offset += self.PAGE_SIZE
            logger.debug(f"[shadowpay] Page {page+1}: {len(batch)} items")

        return ticks

    async def _fetch_page(self, offset: int) -> list[PriceTick]:
        headers = {
            "Accept": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": "https://shadowpay.com/en/csgo-items",
        }

        if self.session_token:
            headers["Authorization"] = f"Bearer {self.session_token}"

        params = {
            "project": "csgo",
            "offset": offset,
            "limit": self.PAGE_SIZE,
            "sort_column": "price",
            "sort_dir": "asc",
        }

        try:
            resp = await self.get(SHADOWPAY_API, params=params, headers=headers)
            data = resp.json()
        except Exception as e:
            logger.warning(f"[shadowpay] Request failed at offset={offset}: {e}")
            return []

        items = data.get("data", [])
        if not items:
            return []

        ticks = []
        for item in items:
            tick = self._parse_item(item)
            if tick:
                ticks.append(tick)

        return ticks

    def _parse_item(self, item: dict) -> Optional[PriceTick]:
        try:
            name = item.get("steam_market_hash_name") or item.get("name", "")
            if not name:
                return None

            price_usd = float(item.get("price", 0) or 0)
            if price_usd <= 0:
                return None

            return PriceTick(
                market_hash_name=name,
                market=self.market_name,
                price_usd=price_usd,
                currency="USD",
                price_original=price_usd,
                listing_count=1,
                market_fee_pct=SHADOWPAY_FEE,
                item_type=item.get("type", ""),
                item_exterior=item.get("exterior", ""),
                item_rarity=item.get("rarity", ""),
            )

        except (KeyError, TypeError, ValueError) as e:
            logger.debug(f"[shadowpay] Parse error: {e}")
            return None
