"""
CSFloat Collector

CSFloat has an official public API.
Endpoint:
  GET https://csfloat.com/api/v1/listings

Provides: listings with float, paint_seed, stickers — premium data.
Rate limit: strict, ~10-15 req/min for unauthenticated.

Note: CSFloat is best for specific items with float/sticker value,
not for bulk price comparison (unlike Skinport).
"""

import logging
from typing import Optional

from .base import BaseCollector, PriceTick

logger = logging.getLogger(__name__)


class CSFloatCollector(BaseCollector):
    """
    Fetches CS2 item listings from CSFloat.
    Speciality: exact float, pattern, and sticker data per listing.
    """

    API_URL = "https://csfloat.com/api/v1/listings"
    MARKET_FEE = 2.0  # CSFloat charges 2% seller fee

    def __init__(self, api_key: Optional[str] = None, **kwargs):
        # CSFloat is strict on rate limiting — go slow
        super().__init__(rate_limit_rps=0.2, **kwargs)
        self.api_key = api_key

    @property
    def market_name(self) -> str:
        return "csfloat"

    @property
    def market_fee_pct(self) -> float:
        return self.MARKET_FEE

    async def fetch_prices(self) -> list[PriceTick]:
        """
        Paginated fetch of all CS2 listings.
        CSFloat has high-quality data but lower volume than Skinport/DMarket.
        """
        ticks = []
        page = 0
        page_size = 50  # CSFloat max
        max_pages = 100  # ~5000 items per run

        while page < max_pages:
            batch = await self._fetch_page(page, page_size)
            if not batch:
                break
            ticks.extend(batch)
            page += 1
            logger.debug(f"[csfloat] Page {page}: {len(batch)} items, total {len(ticks)}")

        return ticks

    async def _fetch_page(self, page: int, limit: int) -> list[PriceTick]:
        headers = {}
        if self.api_key:
            headers["Authorization"] = self.api_key

        params = {
            "limit": limit,
            "page": page,
            "sort_by": "lowest_price",
            "type": "buy_now",
        }

        try:
            resp = await self.get(self.API_URL, params=params, headers=headers)
            data = resp.json()
        except Exception as e:
            logger.warning(f"[csfloat] Page {page} failed: {e}")
            return []

        listings = data.get("data", [])
        return [tick for item in listings if (tick := self._parse_item(item)) is not None]

    def _parse_item(self, listing: dict) -> Optional[PriceTick]:
        try:
            # Price is in USD cents
            price_usd = float(listing.get("price", 0)) / 100.0
            if price_usd <= 0:
                return None

            item = listing.get("item", {})
            name = item.get("market_hash_name", "")
            if not name:
                return None

            float_val = item.get("float_value")
            paint_seed = item.get("paint_seed")
            stickers = item.get("stickers", [])

            # Infer exterior from float
            exterior = _float_to_exterior(float_val, name)

            return PriceTick(
                market_hash_name=name,
                market=self.market_name,
                price_usd=price_usd,
                currency="USD",
                price_original=price_usd,
                listing_count=1,
                market_fee_pct=self.MARKET_FEE,
                item_type=_infer_type(name),
                item_exterior=exterior,
                float_value=float_val,
                paint_seed=paint_seed,
                sticker_count=len(stickers),
            )

        except (KeyError, TypeError, ValueError) as e:
            logger.debug(f"[csfloat] Parse error: {e}")
            return None


def _float_to_exterior(float_val: Optional[float], name: str) -> str:
    """Convert float value to wear name."""
    if float_val is None:
        # Try to extract from name
        for ext in ["Factory New", "Minimal Wear", "Field-Tested", "Well-Worn", "Battle-Scarred"]:
            if ext in name:
                return ext
        return ""
    if float_val <= 0.07:
        return "Factory New"
    elif float_val <= 0.15:
        return "Minimal Wear"
    elif float_val <= 0.38:
        return "Field-Tested"
    elif float_val <= 0.45:
        return "Well-Worn"
    else:
        return "Battle-Scarred"


def _infer_type(name: str) -> str:
    """Infer item type from market_hash_name."""
    keywords = {
        "Knife": "Knife", "Karambit": "Knife", "Bayonet": "Knife",
        "Butterfly": "Knife", "Falchion": "Knife", "Huntsman": "Knife",
        "Gloves": "Gloves", "Wraps": "Gloves",
        "AK-47": "Rifle", "M4A4": "Rifle", "M4A1-S": "Rifle",
        "AWP": "Sniper Rifle", "SSG": "Sniper Rifle", "SCAR": "Sniper Rifle",
        "Glock": "Pistol", "USP": "Pistol", "Desert Eagle": "Pistol",
        "Sticker": "Sticker",
        "Case": "Case",
    }
    for keyword, item_type in keywords.items():
        if keyword in name:
            return item_type
    return "Other"
