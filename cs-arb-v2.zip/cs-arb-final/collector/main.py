"""
Main collector orchestrator.

Runs all market collectors in parallel, writes to ClickHouse,
computes spreads, and caches results in Redis.

Schedule: every COLLECT_INTERVAL_SEC seconds (default: 300 = 5 min)
"""

import asyncio
import json
import logging
import os
import sys
from datetime import datetime, timezone

import redis

from collectors.base import PriceTick
from collectors.skinport import SkinportCollector
from collectors.dmarket import DMarketCollector
from collectors.csfloat import CSFloatCollector
from database.clickhouse_writer import ClickHouseWriter
from spread_calculator import SpreadCalculator, build_price_index

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("orchestrator")


def get_config() -> dict:
    return {
        "clickhouse": {
            "host": os.getenv("CLICKHOUSE_HOST", "localhost"),
            "port": int(os.getenv("CLICKHOUSE_PORT", "9000")),
            "database": os.getenv("CLICKHOUSE_DB", "cs_arb"),
            "username": os.getenv("CLICKHOUSE_USER", "admin"),
            "password": os.getenv("CLICKHOUSE_PASSWORD", "admin123"),
        },
        "redis_url": os.getenv("REDIS_URL", "redis://localhost:6379"),
        "collect_interval": int(os.getenv("COLLECT_INTERVAL_SEC", "300")),
        "csfloat_api_key": os.getenv("CSFLOAT_API_KEY"),
    }


async def run_collectors(cfg: dict) -> dict[str, list[PriceTick]]:
    """Run all collectors concurrently."""
    collectors = [
        SkinportCollector(),
        DMarketCollector(),
        CSFloatCollector(api_key=cfg.get("csfloat_api_key")),
    ]

    logger.info(f"Starting {len(collectors)} collectors in parallel")

    # Run all collectors concurrently
    results = await asyncio.gather(
        *[c.collect() for c in collectors],
        return_exceptions=True
    )

    ticks_by_market: dict[str, list[PriceTick]] = {}

    for result in results:
        if isinstance(result, Exception):
            logger.error(f"Collector failed with exception: {result}")
            continue
        if result.status != "error":
            ticks_by_market[result.market] = result.ticks
            logger.info(
                f"[{result.market}] ✓ {len(result.ticks)} items "
                f"in {result.duration_ms}ms"
            )
        else:
            logger.warning(f"[{result.market}] ✗ Failed: {result.error_message}")

    return ticks_by_market, results


def write_to_clickhouse(
    writer: ClickHouseWriter,
    ticks_by_market: dict[str, list[PriceTick]],
    all_results: list,
    ts: datetime,
):
    """Write all collected data to ClickHouse."""
    total_written = 0

    for market, ticks in ticks_by_market.items():
        written = writer.write_ticks(ticks, ts=ts)
        total_written += written
        logger.info(f"[clickhouse] Wrote {written} ticks from {market}")

    # Write health records for all collectors
    for result in all_results:
        if not isinstance(result, Exception):
            writer.write_health(result, ts=ts)

    logger.info(f"[clickhouse] Total: {total_written} rows written")
    return total_written


def compute_and_cache_spreads(
    ticks_by_market: dict[str, list[PriceTick]],
    redis_client: redis.Redis,
):
    """Compute arbitrage spreads and cache in Redis for the API."""
    price_index = build_price_index(ticks_by_market)
    calculator = SpreadCalculator()

    spreads = calculator.compute_spreads(
        price_index,
        min_profit_pct=2.0,
        min_profit_usd=0.05,
        max_results=1000,
    )

    # Serialize to Redis
    spreads_data = [s.to_dict() for s in spreads]

    pipe = redis_client.pipeline()
    pipe.set("spreads:latest", json.dumps(spreads_data), ex=600)  # 10min TTL
    pipe.set("spreads:last_update", datetime.now(tz=timezone.utc).isoformat(), ex=600)
    pipe.set("spreads:count", len(spreads_data), ex=600)

    # Also cache per-market stats
    for market, ticks in ticks_by_market.items():
        pipe.set(f"market:{market}:item_count", len(ticks), ex=600)

    pipe.execute()

    logger.info(
        f"[spreads] {len(spreads)} profitable opportunities cached in Redis "
        f"| Top: {spreads[0].to_dict() if spreads else 'none'}"
    )

    return spreads


async def main():
    cfg = get_config()
    logger.info("CS-Arb Collector starting up")
    logger.info(f"Collect interval: {cfg['collect_interval']}s")

    # Init storage connections
    writer = ClickHouseWriter(**cfg["clickhouse"])
    writer.connect()

    redis_client = redis.from_url(cfg["redis_url"], decode_responses=True)

    # Verify connections
    if not writer.health_check():
        logger.error("ClickHouse connection failed. Exiting.")
        sys.exit(1)

    redis_client.ping()
    logger.info("Storage connections OK")

    # Main collection loop
    run_count = 0
    while True:
        run_count += 1
        ts = datetime.now(tz=timezone.utc)
        logger.info(f"=== Collection run #{run_count} at {ts.isoformat()} ===")

        try:
            ticks_by_market, all_results = await run_collectors(cfg)

            if ticks_by_market:
                write_to_clickhouse(writer, ticks_by_market, all_results, ts)
                spreads = compute_and_cache_spreads(ticks_by_market, redis_client)

                # Log summary
                counts = writer.get_latest_counts()
                logger.info(f"DB status (last 1h): {counts}")
            else:
                logger.warning("No data collected from any market!")

        except Exception as e:
            logger.error(f"Collection run failed: {e}", exc_info=True)

        logger.info(f"Sleeping {cfg['collect_interval']}s until next run")
        await asyncio.sleep(cfg["collect_interval"])


if __name__ == "__main__":
    asyncio.run(main())
