"""
Alert Engine — Phase 4 / 5

Detects:
  1. Price spikes (sudden +/- movement vs 30d baseline)
  2. Whale movements (volume spike on specific items)
  3. Market panic (broad sell-off across category)
  4. New arbitrage opportunity above threshold
  5. Portfolio item price change (personal alerts)

Publishes alerts to Redis pub/sub → picked up by notification workers.
"""

from __future__ import annotations

import json
import logging
import statistics
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

import redis

logger = logging.getLogger(__name__)


class AlertType(str, Enum):
    PRICE_SPIKE_UP   = "price_spike_up"
    PRICE_SPIKE_DOWN = "price_spike_down"
    WHALE_BUY        = "whale_buy"
    WHALE_SELL       = "whale_sell"
    MARKET_PANIC     = "market_panic"
    SPREAD_FOUND     = "spread_found"
    PORTFOLIO_CHANGE = "portfolio_change"


class AlertSeverity(str, Enum):
    INFO    = "info"
    WARNING = "warning"
    URGENT  = "urgent"


@dataclass
class Alert:
    type: AlertType
    severity: AlertSeverity
    title: str
    body: str
    market_hash_name: Optional[str] = None
    market: Optional[str] = None
    current_value: Optional[float] = None
    baseline_value: Optional[float] = None
    change_pct: Optional[float] = None
    ts: str = field(default_factory=lambda: datetime.now(tz=timezone.utc).isoformat())
    extra: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)


# ── Detectors ─────────────────────────────────────────────────────────────────

class PriceSpikeDetector:
    """
    Detects when an item's price moves significantly vs its recent baseline.

    Uses z-score: (current_price - mean_30d) / std_30d > threshold → alert
    """

    def __init__(
        self,
        spike_threshold_z: float = 2.5,   # z-score above which = spike
        min_change_pct: float = 10.0,      # also require >10% absolute change
    ):
        self.threshold_z = spike_threshold_z
        self.min_change_pct = min_change_pct

    def detect(
        self,
        item: str,
        market: str,
        current_price: float,
        price_history_30d: list[float],    # list of recent prices
    ) -> Optional[Alert]:
        if len(price_history_30d) < 10:
            return None  # Not enough data

        mean = statistics.mean(price_history_30d)
        std  = statistics.stdev(price_history_30d)

        if std < 0.001:
            return None

        z_score = (current_price - mean) / std
        change_pct = (current_price - mean) / mean * 100

        if abs(z_score) < self.threshold_z:
            return None
        if abs(change_pct) < self.min_change_pct:
            return None

        is_spike_up = z_score > 0
        alert_type = AlertType.PRICE_SPIKE_UP if is_spike_up else AlertType.PRICE_SPIKE_DOWN
        severity = AlertSeverity.URGENT if abs(z_score) > 4.0 else AlertSeverity.WARNING

        direction = "⬆ SPIKE" if is_spike_up else "⬇ DROP"
        sign = "+" if change_pct > 0 else ""

        return Alert(
            type=alert_type,
            severity=severity,
            title=f"{direction}: {item}",
            body=(
                f"{market.upper()} | ${current_price:.2f} "
                f"({sign}{change_pct:.1f}% vs 30d avg ${mean:.2f})"
            ),
            market_hash_name=item,
            market=market,
            current_value=current_price,
            baseline_value=round(mean, 2),
            change_pct=round(change_pct, 1),
            extra={"z_score": round(z_score, 2), "std": round(std, 4)},
        )


class VolumeAnomalyDetector:
    """
    Detects unusual volume spikes — potential whale activity.
    """

    def __init__(
        self,
        spike_multiplier: float = 5.0,  # volume > 5x average = whale signal
        min_volume: int = 10,
    ):
        self.spike_multiplier = spike_multiplier
        self.min_volume = min_volume

    def detect(
        self,
        item: str,
        market: str,
        current_volume: int,
        avg_volume_7d: float,
    ) -> Optional[Alert]:
        if avg_volume_7d < 1 or current_volume < self.min_volume:
            return None

        ratio = current_volume / avg_volume_7d

        if ratio < self.spike_multiplier:
            return None

        severity = AlertSeverity.URGENT if ratio > 10 else AlertSeverity.WARNING

        return Alert(
            type=AlertType.WHALE_BUY,
            severity=severity,
            title=f"🐳 WHALE ACTIVITY: {item}",
            body=(
                f"{market.upper()} | Volume {current_volume} "
                f"({ratio:.1f}x avg {avg_volume_7d:.0f}/day)"
            ),
            market_hash_name=item,
            market=market,
            current_value=float(current_volume),
            baseline_value=round(avg_volume_7d, 1),
            change_pct=round((ratio - 1) * 100, 0),
            extra={"volume_ratio": round(ratio, 2)},
        )


class MarketPanicDetector:
    """
    Detects broad market sell-offs: if >30% of items in a category
    drop more than 5% in one collection cycle.
    """

    def __init__(
        self,
        panic_threshold_pct: float = 5.0,   # individual drop %
        panic_breadth_pct: float = 30.0,     # % of items dropping
    ):
        self.panic_threshold = panic_threshold_pct
        self.panic_breadth = panic_breadth_pct

    def detect(
        self,
        category: str,           # e.g. "Rifle", "Knife"
        price_changes: list[float],  # % changes for each item in category
    ) -> Optional[Alert]:
        if len(price_changes) < 5:
            return None

        dropping = [c for c in price_changes if c < -self.panic_threshold]
        breadth = len(dropping) / len(price_changes) * 100

        if breadth < self.panic_breadth:
            return None

        avg_drop = statistics.mean(dropping)
        severity = AlertSeverity.URGENT if breadth > 50 else AlertSeverity.WARNING

        return Alert(
            type=AlertType.MARKET_PANIC,
            severity=severity,
            title=f"🚨 MARKET PANIC: {category}",
            body=(
                f"{breadth:.0f}% of {category} items dropped "
                f"avg {avg_drop:.1f}% in last cycle"
            ),
            change_pct=round(avg_drop, 1),
            extra={
                "category": category,
                "items_dropping": len(dropping),
                "total_items": len(price_changes),
                "breadth_pct": round(breadth, 1),
            },
        )


# ── Alert Manager ──────────────────────────────────────────────────────────────

class AlertManager:
    """
    Coordinates detectors, deduplicates alerts, and publishes to Redis.
    Downstream: push notification workers subscribe to Redis channel.
    """

    CHANNEL = "cs_arb:alerts"
    DEDUP_TTL = 3600   # Don't re-fire same alert within 1 hour

    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.spike_detector   = PriceSpikeDetector()
        self.volume_detector  = VolumeAnomalyDetector()
        self.panic_detector   = MarketPanicDetector()

    def publish(self, alert: Alert) -> bool:
        """
        Publish alert to Redis pub/sub.
        Returns True if published (not duplicate).
        """
        dedup_key = f"alert_dedup:{alert.type}:{alert.market_hash_name}:{alert.market}"

        # Check dedup
        if self.redis.exists(dedup_key):
            logger.debug(f"Alert suppressed (duplicate): {alert.title}")
            return False

        # Set dedup lock
        self.redis.setex(dedup_key, self.DEDUP_TTL, "1")

        # Publish to channel
        payload = json.dumps(alert.to_dict())
        self.redis.publish(self.CHANNEL, payload)

        # Also keep recent alerts in a sorted set (for history/UI)
        import time
        self.redis.zadd(
            "alerts:recent",
            {payload: time.time()},
        )
        # Keep only last 500 alerts
        self.redis.zremrangebyrank("alerts:recent", 0, -501)

        logger.info(f"Alert published: [{alert.severity}] {alert.title}")
        return True

    def process_price_update(
        self,
        item: str,
        market: str,
        current_price: float,
        current_volume: int,
        price_history_30d: list[float],
        avg_volume_7d: float,
    ):
        """Run all detectors on a price update."""
        alerts = []

        # Spike detection
        spike = self.spike_detector.detect(
            item, market, current_price, price_history_30d
        )
        if spike:
            alerts.append(spike)

        # Volume/whale detection
        whale = self.volume_detector.detect(
            item, market, current_volume, avg_volume_7d
        )
        if whale:
            alerts.append(whale)

        for alert in alerts:
            self.publish(alert)

    def process_spread_found(
        self,
        item: str,
        buy_market: str,
        sell_market: str,
        net_profit_pct: float,
        net_profit_usd: float,
        threshold_pct: float = 15.0,  # only alert on high-value spreads
    ):
        """Alert when an unusually profitable spread is detected."""
        if net_profit_pct < threshold_pct:
            return

        alert = Alert(
            type=AlertType.SPREAD_FOUND,
            severity=AlertSeverity.URGENT,
            title=f"💰 SPREAD ALERT: +{net_profit_pct:.1f}%",
            body=(
                f"{item} | Buy {buy_market.upper()} → Sell {sell_market.upper()} "
                f"| +${net_profit_usd:.2f} net"
            ),
            market_hash_name=item,
            change_pct=round(net_profit_pct, 1),
            extra={
                "buy_market": buy_market,
                "sell_market": sell_market,
                "net_profit_usd": round(net_profit_usd, 2),
            },
        )
        self.publish(alert)

    def get_recent_alerts(self, limit: int = 50) -> list[dict]:
        """Fetch recent alerts for the UI."""
        raw = self.redis.zrevrange("alerts:recent", 0, limit - 1)
        alerts = []
        for r in raw:
            try:
                alerts.append(json.loads(r))
            except Exception:
                pass
        return alerts
