"""
Portfolio Tracker

Manages user portfolios: holdings, P&L tracking, cost basis.
Stores positions in PostgreSQL, marks-to-market from ClickHouse/Redis.

Supports:
  - Add/remove positions
  - Cost basis (FIFO / weighted average)
  - Unrealized P&L vs current bid/ask
  - Portfolio-level risk metrics
  - Item-level performance history
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional
import json

logger = logging.getLogger(__name__)


class CostBasisMethod(str, Enum):
    FIFO             = "fifo"
    WEIGHTED_AVERAGE = "wavg"


@dataclass
class Position:
    """One skin holding in a portfolio."""
    id: int
    user_id: str
    market_hash_name: str
    quantity: int
    cost_basis_usd: float         # avg cost per unit
    total_cost_usd: float         # cost_basis * quantity
    buy_date: datetime
    buy_market: str
    # Filled from market data
    current_price_usd: float = 0.0
    current_market: str = ""
    unrealized_pnl_usd: float = 0.0
    unrealized_pnl_pct: float = 0.0
    # Metadata
    float_value: Optional[float] = None
    notes: str = ""

    def mark_to_market(self, current_price: float, current_market: str = ""):
        """Update unrealized P&L based on current price."""
        self.current_price_usd = current_price
        self.current_market = current_market
        pnl = (current_price - self.cost_basis_usd) * self.quantity
        pnl_pct = (current_price - self.cost_basis_usd) / self.cost_basis_usd * 100
        self.unrealized_pnl_usd = round(pnl, 2)
        self.unrealized_pnl_pct = round(pnl_pct, 1)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "item": self.market_hash_name,
            "quantity": self.quantity,
            "cost_basis": round(self.cost_basis_usd, 2),
            "total_cost": round(self.total_cost_usd, 2),
            "current_price": round(self.current_price_usd, 2),
            "unrealized_pnl_usd": self.unrealized_pnl_usd,
            "unrealized_pnl_pct": self.unrealized_pnl_pct,
            "buy_date": self.buy_date.isoformat(),
            "buy_market": self.buy_market,
            "float": self.float_value,
            "notes": self.notes,
        }


@dataclass
class PortfolioSummary:
    """Aggregate portfolio metrics."""
    user_id: str
    positions: list[Position] = field(default_factory=list)

    @property
    def total_cost(self) -> float:
        return sum(p.total_cost_usd for p in self.positions)

    @property
    def total_market_value(self) -> float:
        return sum(p.current_price_usd * p.quantity for p in self.positions)

    @property
    def total_unrealized_pnl(self) -> float:
        return sum(p.unrealized_pnl_usd for p in self.positions)

    @property
    def total_unrealized_pnl_pct(self) -> float:
        if self.total_cost <= 0:
            return 0
        return self.total_unrealized_pnl / self.total_cost * 100

    @property
    def top_winners(self) -> list[Position]:
        return sorted(
            [p for p in self.positions if p.unrealized_pnl_pct > 0],
            key=lambda p: p.unrealized_pnl_pct,
            reverse=True,
        )[:5]

    @property
    def top_losers(self) -> list[Position]:
        return sorted(
            [p for p in self.positions if p.unrealized_pnl_pct < 0],
            key=lambda p: p.unrealized_pnl_pct,
        )[:5]

    @property
    def category_allocation(self) -> dict[str, float]:
        """% of portfolio value by item type."""
        by_type: dict[str, float] = {}
        total = self.total_market_value or 1
        for p in self.positions:
            category = _infer_category(p.market_hash_name)
            by_type[category] = by_type.get(category, 0) + (p.current_price_usd * p.quantity)
        return {k: round(v / total * 100, 1) for k, v in by_type.items()}

    def to_dict(self) -> dict:
        return {
            "user_id": self.user_id,
            "total_cost_usd": round(self.total_cost, 2),
            "total_market_value_usd": round(self.total_market_value, 2),
            "unrealized_pnl_usd": round(self.total_unrealized_pnl, 2),
            "unrealized_pnl_pct": round(self.total_unrealized_pnl_pct, 1),
            "position_count": len(self.positions),
            "top_winners": [p.to_dict() for p in self.top_winners],
            "top_losers": [p.to_dict() for p in self.top_losers],
            "category_allocation": self.category_allocation,
            "positions": [p.to_dict() for p in self.positions],
        }


# ── PostgreSQL Schema (for reference) ─────────────────────────────────────────
PORTFOLIO_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS portfolios (
    id          SERIAL PRIMARY KEY,
    user_id     VARCHAR(64) NOT NULL,
    name        VARCHAR(128) DEFAULT 'My Portfolio',
    created_at  TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS positions (
    id                  SERIAL PRIMARY KEY,
    portfolio_id        INTEGER REFERENCES portfolios(id) ON DELETE CASCADE,
    user_id             VARCHAR(64) NOT NULL,
    market_hash_name    TEXT NOT NULL,
    quantity            INTEGER NOT NULL DEFAULT 1,
    cost_basis_usd      NUMERIC(12, 4) NOT NULL,
    total_cost_usd      NUMERIC(12, 4) NOT NULL,
    buy_date            TIMESTAMPTZ NOT NULL DEFAULT now(),
    buy_market          VARCHAR(32),
    float_value         NUMERIC(10, 8),
    paint_seed          INTEGER,
    notes               TEXT DEFAULT '',
    closed              BOOLEAN DEFAULT FALSE,
    sold_price_usd      NUMERIC(12, 4),
    sold_date           TIMESTAMPTZ,
    realized_pnl_usd    NUMERIC(12, 4)
);

CREATE INDEX IF NOT EXISTS positions_user_idx ON positions(user_id);
CREATE INDEX IF NOT EXISTS positions_item_idx ON positions(market_hash_name);

CREATE TABLE IF NOT EXISTS portfolio_snapshots (
    id                  SERIAL PRIMARY KEY,
    user_id             VARCHAR(64) NOT NULL,
    ts                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    total_cost_usd      NUMERIC(12, 2),
    total_value_usd     NUMERIC(12, 2),
    unrealized_pnl_usd  NUMERIC(12, 2),
    position_count      INTEGER
);

CREATE INDEX IF NOT EXISTS snapshots_user_ts ON portfolio_snapshots(user_id, ts);
"""


# ── Portfolio Service ─────────────────────────────────────────────────────────

class PortfolioService:
    """
    CRUD + analytics for user portfolios.
    Uses asyncpg for PostgreSQL and Redis for price cache.
    """

    def __init__(self, pg_pool, redis_client):
        self.pg = pg_pool
        self.redis = redis_client

    async def add_position(
        self,
        user_id: str,
        market_hash_name: str,
        cost_basis_usd: float,
        quantity: int = 1,
        buy_market: str = "",
        float_value: Optional[float] = None,
        notes: str = "",
    ) -> int:
        """Add a new position to the portfolio. Returns position ID."""
        total_cost = cost_basis_usd * quantity
        buy_date = datetime.now(tz=timezone.utc)

        async with self.pg.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO positions
                (user_id, market_hash_name, quantity, cost_basis_usd,
                 total_cost_usd, buy_date, buy_market, float_value, notes)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                RETURNING id
            """, user_id, market_hash_name, quantity, cost_basis_usd,
                total_cost, buy_date, buy_market, float_value, notes)

        pos_id = row["id"]
        logger.info(f"Position added: {market_hash_name} x{quantity} @ ${cost_basis_usd} (id={pos_id})")
        return pos_id

    async def close_position(
        self,
        position_id: int,
        user_id: str,
        sold_price_usd: float,
    ) -> dict:
        """Mark a position as sold. Calculate realized P&L."""
        async with self.pg.acquire() as conn:
            pos = await conn.fetchrow(
                "SELECT * FROM positions WHERE id=$1 AND user_id=$2 AND NOT closed",
                position_id, user_id
            )
            if not pos:
                raise ValueError(f"Position {position_id} not found or already closed")

            realized_pnl = (sold_price_usd - pos["cost_basis_usd"]) * pos["quantity"]

            await conn.execute("""
                UPDATE positions
                SET closed=TRUE, sold_price_usd=$1, sold_date=now(), realized_pnl_usd=$2
                WHERE id=$3
            """, sold_price_usd, realized_pnl, position_id)

        logger.info(f"Position {position_id} closed: sold at ${sold_price_usd}, P&L=${realized_pnl:.2f}")
        return {"realized_pnl_usd": round(realized_pnl, 2)}

    async def get_portfolio(self, user_id: str) -> PortfolioSummary:
        """Get all open positions with current market prices."""
        async with self.pg.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM positions WHERE user_id=$1 AND NOT closed ORDER BY buy_date DESC",
                user_id
            )

        positions = []
        for row in rows:
            pos = Position(
                id=row["id"],
                user_id=user_id,
                market_hash_name=row["market_hash_name"],
                quantity=row["quantity"],
                cost_basis_usd=float(row["cost_basis_usd"]),
                total_cost_usd=float(row["total_cost_usd"]),
                buy_date=row["buy_date"],
                buy_market=row["buy_market"] or "",
                float_value=row["float_value"],
                notes=row["notes"] or "",
            )

            # Fetch current price from Redis cache
            current_price = await self._get_cached_price(pos.market_hash_name)
            if current_price:
                pos.mark_to_market(current_price)

            positions.append(pos)

        return PortfolioSummary(user_id=user_id, positions=positions)

    async def _get_cached_price(self, item: str) -> Optional[float]:
        """Get best current price from Redis spread cache."""
        # Check per-item price cache
        cached = self.redis.get(f"price:{item}:best")
        if cached:
            return float(cached)
        return None

    async def save_snapshot(self, summary: PortfolioSummary):
        """Save portfolio value snapshot for equity curve tracking."""
        async with self.pg.acquire() as conn:
            await conn.execute("""
                INSERT INTO portfolio_snapshots
                (user_id, total_cost_usd, total_value_usd, unrealized_pnl_usd, position_count)
                VALUES ($1, $2, $3, $4, $5)
            """,
                summary.user_id,
                summary.total_cost,
                summary.total_market_value,
                summary.total_unrealized_pnl,
                len(summary.positions),
            )

    async def get_equity_curve(self, user_id: str, days: int = 90) -> list[dict]:
        """Portfolio value over time."""
        async with self.pg.acquire() as conn:
            rows = await conn.fetch("""
                SELECT ts, total_value_usd, unrealized_pnl_usd
                FROM portfolio_snapshots
                WHERE user_id=$1 AND ts >= now() - INTERVAL '1 day' * $2
                ORDER BY ts ASC
            """, user_id, days)

        return [
            {
                "ts": row["ts"].isoformat(),
                "value": float(row["total_value_usd"]),
                "pnl": float(row["unrealized_pnl_usd"]),
            }
            for row in rows
        ]


def _infer_category(name: str) -> str:
    """Infer category from market_hash_name."""
    if any(k in name for k in ["Knife", "Karambit", "Bayonet", "Butterfly", "Huntsman", "Falchion"]):
        return "Knife"
    if "Gloves" in name or "Wraps" in name:
        return "Gloves"
    if any(k in name for k in ["AK-47", "M4A4", "M4A1", "FAMAS", "Galil"]):
        return "Rifle"
    if "AWP" in name or "SSG" in name or "SCAR" in name or "G3SG1" in name:
        return "Sniper"
    if "Sticker" in name:
        return "Sticker"
    if "Case" in name or "Container" in name:
        return "Case"
    if "Glock" in name or "USP" in name or "Desert Eagle" in name or "P2000" in name:
        return "Pistol"
    return "Other"
