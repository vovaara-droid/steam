"""
Spread Calculator — the core engine of the platform.

Takes normalized prices from multiple markets, computes:
  - gross spread
  - net profit after fees
  - liquidity score
  - risk flags

This is the "real profitable spread" formula from the spec.
"""

import logging
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

# Currency conversion to USD (extend with live rates later)
# For now, Steam prices are USD-equivalent via their market
CURRENCY_TO_USD = {
    "USD": 1.0,
    "EUR": 1.08,
    "CNY": 0.14,
    "RUB": 0.011,
    "GBP": 1.27,
}


@dataclass
class MarketPrice:
    """Aggregated price data for one item on one market."""
    market: str
    price_usd: float
    fee_pct: float
    listing_count: int
    # Derived
    effective_buy_price: float = 0.0   # what buyer pays
    effective_sell_proceeds: float = 0.0  # what seller receives

    def __post_init__(self):
        # Buyer pays price_usd directly
        self.effective_buy_price = self.price_usd
        # Seller receives price minus the market's cut
        self.effective_sell_proceeds = self.price_usd * (1 - self.fee_pct / 100)


@dataclass
class SpreadResult:
    """Computed arbitrage spread between two markets."""
    market_hash_name: str

    buy_market: str
    buy_price_usd: float
    buy_fee_pct: float

    sell_market: str
    sell_price_usd: float
    sell_fee_pct: float

    # Core profit metrics
    gross_spread_usd: float           # sell - buy (ignoring fees)
    gross_spread_pct: float           # gross / buy * 100
    net_profit_usd: float             # after all fees
    net_profit_pct: float             # net / buy * 100

    # Liquidity / risk
    buy_listing_count: int
    sell_listing_count: int
    liquidity_score: float            # 0..1
    is_profitable: bool               # net_profit_usd > 0

    # Optional context
    item_type: str = ""
    item_exterior: str = ""
    notes: list[str] = field(default_factory=list)

    @property
    def roi_estimate(self) -> float:
        """Estimated monthly ROI assuming one flip per week."""
        return self.net_profit_pct * 4

    def to_dict(self) -> dict:
        return {
            "item": self.market_hash_name,
            "buy_market": self.buy_market,
            "sell_market": self.sell_market,
            "buy_price": round(self.buy_price_usd, 2),
            "sell_price": round(self.sell_price_usd, 2),
            "net_profit_usd": round(self.net_profit_usd, 2),
            "net_profit_pct": round(self.net_profit_pct, 2),
            "gross_spread_pct": round(self.gross_spread_pct, 2),
            "liquidity_score": round(self.liquidity_score, 3),
            "buy_listings": self.buy_listing_count,
            "sell_listings": self.sell_listing_count,
            "is_profitable": self.is_profitable,
            "item_type": self.item_type,
            "item_exterior": self.item_exterior,
            "notes": self.notes,
            "estimated_monthly_roi_pct": round(self.roi_estimate, 1),
        }


class SpreadCalculator:
    """
    Multi-market arbitrage spread calculator.

    Takes a dict {market_name: {item_name: MarketPrice}}
    and returns sorted list of SpreadResult.
    """

    # Minimum profit thresholds for filtering noise
    MIN_NET_PROFIT_USD = 0.10
    MIN_NET_PROFIT_PCT = 3.0
    MIN_SELL_LISTINGS = 1

    # Trade lock penalty: items with 7-day lock sell for ~10% less
    TRADE_LOCK_DISCOUNT = 0.10

    def compute_spreads(
        self,
        prices: dict[str, dict[str, MarketPrice]],  # {market: {item_name: price}}
        min_profit_pct: float = MIN_NET_PROFIT_PCT,
        min_profit_usd: float = MIN_NET_PROFIT_USD,
        max_results: int = 500,
    ) -> list[SpreadResult]:
        """
        Main entry point. Compares all market pairs for each item.

        prices: {
            'skinport': {'AK-47 | Redline (Field-Tested)': MarketPrice(...)},
            'dmarket':  {'AK-47 | Redline (Field-Tested)': MarketPrice(...)},
            ...
        }
        """
        # Build inverted index: item → {market: price}
        item_index: dict[str, dict[str, MarketPrice]] = {}

        for market, items in prices.items():
            for item_name, mp in items.items():
                if item_name not in item_index:
                    item_index[item_name] = {}
                item_index[item_name][market] = mp

        # Only process items available on at least 2 markets
        results = []
        for item_name, market_prices in item_index.items():
            if len(market_prices) < 2:
                continue

            item_spreads = self._compute_item_spreads(item_name, market_prices)
            results.extend(item_spreads)

        # Filter by profit thresholds
        results = [
            r for r in results
            if r.net_profit_usd >= min_profit_usd
            and r.net_profit_pct >= min_profit_pct
        ]

        # Sort by net profit % descending (or use net_profit_usd for high-value focus)
        results.sort(key=lambda r: r.net_profit_pct, reverse=True)

        logger.info(
            f"Spread computation: {len(item_index)} items, "
            f"{len(results)} profitable spreads found"
        )

        return results[:max_results]

    def _compute_item_spreads(
        self,
        item_name: str,
        market_prices: dict[str, MarketPrice],
    ) -> list[SpreadResult]:
        """Compute all buy/sell market combinations for one item."""
        results = []
        markets = list(market_prices.keys())

        for i, buy_market in enumerate(markets):
            for sell_market in markets:
                if buy_market == sell_market:
                    continue

                buy = market_prices[buy_market]
                sell = market_prices[sell_market]

                spread = self._calculate_spread(item_name, buy_market, buy, sell_market, sell)
                if spread:
                    results.append(spread)

        return results

    def _calculate_spread(
        self,
        item_name: str,
        buy_market: str,
        buy: MarketPrice,
        sell_market: str,
        sell: MarketPrice,
    ) -> Optional[SpreadResult]:
        """
        Core spread calculation.

        Formula:
          net_profit = sell.effective_sell_proceeds - buy.effective_buy_price
          net_profit_pct = net_profit / buy.effective_buy_price * 100
        """
        try:
            # What I pay to buy
            buy_cost = buy.effective_buy_price

            # What I receive after selling and paying fees
            sell_proceeds = sell.effective_sell_proceeds

            gross_spread_usd = sell.price_usd - buy.price_usd
            gross_spread_pct = (gross_spread_usd / buy.price_usd) * 100

            net_profit_usd = sell_proceeds - buy_cost
            net_profit_pct = (net_profit_usd / buy_cost) * 100

            # Liquidity score: geometric mean of normalized listing counts
            # Scale: 0–10 listings = low, 10–100 = medium, 100+ = high
            buy_liq = min(buy.listing_count / 50.0, 1.0)
            sell_liq = min(sell.listing_count / 50.0, 1.0)
            liquidity_score = (buy_liq * sell_liq) ** 0.5

            notes = []

            # Risk flags
            if buy.listing_count < 3:
                notes.append("⚠ Low buy liquidity")
            if sell.listing_count < 3:
                notes.append("⚠ Low sell liquidity")
            if buy_cost < 0.50:
                notes.append("⚠ Very cheap item — high relative fee impact")
            if net_profit_pct > 30:
                notes.append("⚠ Unusually high spread — verify manually")

            return SpreadResult(
                market_hash_name=item_name,
                buy_market=buy_market,
                buy_price_usd=buy.price_usd,
                buy_fee_pct=buy.fee_pct,
                sell_market=sell_market,
                sell_price_usd=sell.price_usd,
                sell_fee_pct=sell.fee_pct,
                gross_spread_usd=gross_spread_usd,
                gross_spread_pct=gross_spread_pct,
                net_profit_usd=net_profit_usd,
                net_profit_pct=net_profit_pct,
                buy_listing_count=buy.listing_count,
                sell_listing_count=sell.listing_count,
                liquidity_score=liquidity_score,
                is_profitable=net_profit_usd > 0,
                notes=notes,
            )

        except ZeroDivisionError:
            logger.debug(f"Zero price for {item_name}")
            return None


def build_price_index(
    ticks_by_market: dict[str, list]  # {market: list[PriceTick]}
) -> dict[str, dict[str, MarketPrice]]:
    """
    Convert raw PriceTicks into the aggregated MarketPrice index
    needed by SpreadCalculator.

    For items with multiple listings, uses the LOWEST price (best for buyer).
    """
    index: dict[str, dict[str, MarketPrice]] = {}

    for market, ticks in ticks_by_market.items():
        index[market] = {}
        for tick in ticks:
            name = tick.market_hash_name
            # Keep the lowest price per item per market
            if name not in index[market] or tick.price_usd < index[market][name].price_usd:
                index[market][name] = MarketPrice(
                    market=market,
                    price_usd=tick.price_usd,
                    fee_pct=tick.market_fee_pct,
                    listing_count=tick.listing_count,
                )

    return index
