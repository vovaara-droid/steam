# CS-ARB Platform

Multi-market CS2 skin arbitrage analytics platform.

## Architecture

```
[Collectors: Skinport, DMarket, CSFloat, Steam, ShadowPay]
       ↓ every 5 min (parallel)
[Spread Calculator] → [Redis: hot cache, pub/sub alerts]
       ↓                      ↓
[ClickHouse: price history]  [FastAPI: REST + WebSocket]
       ↓                      ↓
[Backtesting Engine]   [Dashboard / Mobile]
```

## Quick Start

```bash
# 1. Clone and configure
cp .env.example .env
# Edit .env — at minimum change passwords

# 2. Start everything
make up

# 3. Open the dashboard
open dashboard/index.html

# 4. Check API docs
open http://localhost:8000/docs
```

First collection run starts automatically. Skinport + DMarket
will have data within ~2-3 minutes. Steam takes longer (~20 min).

## Services

| Service     | URL                       | Purpose                        |
|-------------|---------------------------|--------------------------------|
| API         | http://localhost:8000     | REST API + WebSocket           |
| API Docs    | http://localhost:8000/docs| Swagger UI                     |
| ClickHouse  | http://localhost:8123     | Query price history directly   |
| Redis       | localhost:6379            | Live spreads cache             |
| Dashboard   | dashboard/index.html      | Local HTML — open in browser   |

## Key API Endpoints

```
GET  /spreads              Current arbitrage opportunities
GET  /spreads?min_profit_pct=10&buy_market=skinport
GET  /price/{item}         Price history (OHLCV candles)
GET  /markets              Market collector health
GET  /search?q=ak-47       Search items
GET  /analytics/{item}     Deep analytics for one item
GET  /alerts               Recent price alerts

POST /backtest             Run strategy backtest
     ?start=2024-01-01&end=2024-12-31&initial_capital=1000

GET  /portfolio/{user_id}  User portfolio with P&L
POST /portfolio/{user_id}/add?item=...&cost_basis=...

WS   /ws/spreads           Real-time spread updates
```

## Market Coverage & Fees

| Market     | Fee (seller) | API Type        | Rate Limit    |
|------------|-------------|-----------------|---------------|
| Skinport   | 12-15%      | Public REST     | ~10 req/min   |
| DMarket    | 4-7%        | Public REST     | ~20 req/min   |
| CSFloat    | 2%          | Public REST     | ~15 req/min   |
| Steam      | 15%         | Scraping        | 1 req/3s      |
| ShadowPay  | 5%          | Semi-private    | needs proxy   |
| Buff163    | 2.5%        | Scraping (CN)   | needs proxy   |

## Development

```bash
make logs              # Watch all logs
make test-skinport     # Test one collector
make test-spreads      # See cached spreads
make db-shell          # Direct ClickHouse queries
```

### Adding a new market collector

1. Create `collector/collectors/yourmarket.py`
2. Subclass `BaseCollector`, implement `market_name`, `market_fee_pct`, `fetch_prices()`
3. Add to `collectors/__init__.py`
4. Add to the collector list in `collector/main.py`
5. Add fee info to the spread calculator

### Running backtests

```bash
curl -X POST "http://localhost:8000/backtest?\
  start=2024-01-01&end=2024-06-30&\
  initial_capital=1000&min_profit_pct=5"
```

Backtest needs historical data. The longer you've been collecting,
the more accurate your backtests. Start collecting NOW — every day
matters.

## Project Structure

```
cs-arb/
├── docker-compose.yml
├── .env.example
├── Makefile
│
├── collector/                   # Data collection service
│   ├── main.py                  # Orchestrator (runs all collectors)
│   ├── spread_calculator.py     # Core arbitrage math
│   ├── backtesting.py           # Strategy backtesting engine
│   ├── alerts.py                # Anomaly detection + alert pub/sub
│   ├── portfolio.py             # Portfolio tracking + P&L
│   ├── collectors/
│   │   ├── base.py              # Abstract base + rate limiter
│   │   ├── skinport.py          # Skinport public API
│   │   ├── dmarket.py           # DMarket paginated API
│   │   ├── csfloat.py           # CSFloat API (float/pattern data)
│   │   ├── steam.py             # Steam Market (scraping)
│   │   └── shadowpay.py         # ShadowPay (semi-private)
│   └── database/
│       ├── clickhouse_init.sql  # Schema: price_ticks, spreads, candles
│       └── clickhouse_writer.py # Batch writer
│
├── api/                         # FastAPI backend
│   └── main.py                  # All REST + WebSocket endpoints
│
└── dashboard/
    └── index.html               # Trader terminal UI
```

## Roadmap

- **Phase 1** ✅ Data collection infrastructure
- **Phase 2** ✅ Arbitrage terminal (spreads, dashboard, API)
- **Phase 3** ✅ Backtesting engine + portfolio tracker
- **Phase 4** 🔧 ML price forecasting + alert refinement
- **Phase 5** ⬜ Mobile app (React Native) + push notifications
- **Phase 6** ⬜ B2B API + team dashboards

## Legal Notes

- Only use official public APIs where available
- Don't use automated Steam trading bots (violates ToS)
- Price data collection from public pages is generally OK
- Proxy usage: use residential proxies, respect robots.txt
- This platform is for information only — users make their own trading decisions
