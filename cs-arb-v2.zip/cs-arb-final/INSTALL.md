# CS-ARB Platform — Інструкція з встановлення

---

## Вимоги

| Що | Мінімум | Рекомендовано |
|----|---------|---------------|
| OS | Windows 10, macOS 12, Ubuntu 20.04 | Ubuntu 22.04 LTS |
| RAM | 4 GB | 8+ GB |
| Диск | 10 GB вільно | 50+ GB (для históричних даних) |
| CPU | 2 ядра | 4+ ядра |
| Docker | 24.0+ | latest |
| Docker Compose | 2.20+ | latest |

---

## Крок 1 — Встановлення Docker

### macOS

```bash
# Завантаж Docker Desktop з офіційного сайту:
# https://www.docker.com/products/docker-desktop/
# Встанови .dmg, запусти Docker Desktop
# Перевір:
docker --version
docker compose version
```

### Ubuntu / Debian

```bash
# Видалити старі версії
sudo apt remove docker docker-engine docker.io containerd runc

# Встановити залежності
sudo apt update
sudo apt install -y ca-certificates curl gnupg

# Додати офіційний репозиторій Docker
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | \
  sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo $VERSION_CODENAME) stable" | \
sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Встановити Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Дозволити запуск без sudo
sudo usermod -aG docker $USER
newgrp docker

# Перевірка
docker --version         # Docker version 26.x.x
docker compose version   # Docker Compose version v2.x.x
```

### Windows

```
1. Завантаж Docker Desktop: https://www.docker.com/products/docker-desktop/
2. Встанови з параметрами за замовчуванням
3. Після встановлення — перезавантаж комп'ютер
4. Відкрий Docker Desktop, дочекайся "Docker is running"
5. Відкрий PowerShell або Windows Terminal:
   docker --version
   docker compose version
```

---

## Крок 2 — Розпакування проекту

```bash
# Розпакуй архів cs-arb-platform.zip
unzip cs-arb-platform.zip

# Перейди в папку проекту
cd cs-arb

# Перевір структуру
ls -la
```

Ти повинен побачити:
```
.env.example
Makefile
README.md
api/
collector/
dashboard/
docker-compose.yml
```

---

## Крок 3 — Налаштування конфігурації

```bash
# Скопіюй шаблон конфігурації
cp .env.example .env

# Відкрий для редагування
nano .env        # або: code .env / vim .env / notepad .env
```

**Мінімальна конфігурація — змін лише паролі:**

```env
CLICKHOUSE_PASSWORD=мій_надійний_пароль_123
POSTGRES_PASSWORD=мій_надійний_пароль_456

COLLECT_INTERVAL_SEC=300
LOG_LEVEL=INFO

# Ключі API (необов'язково на старті)
CSFLOAT_API_KEY=
SHADOWPAY_TOKEN=
```

> ⚠️ **Важливо:** паролі не повинні містити `@`, `#`, `$` — вони ламають URL рядки підключення.
> Використовуй лише букви, цифри, `_`, `-`.

---

## Крок 4 — Запуск платформи

```bash
# Запуск всіх сервісів (перший раз завантажує образи ~5-10 хв)
docker compose up -d --build
```

Ти побачиш щось таке:
```
[+] Running 5/5
 ✔ Network cs-arb_default     Created
 ✔ Container cs_clickhouse    Started
 ✔ Container cs_postgres      Started
 ✔ Container cs_redis         Started
 ✔ Container cs_collector     Started
 ✔ Container cs_api           Started
```

**Перевір що все запущено:**
```bash
docker compose ps
```

Очікуваний результат:
```
NAME              STATUS          PORTS
cs_clickhouse     Up (healthy)    0.0.0.0:8123->8123/tcp
cs_postgres       Up (healthy)    0.0.0.0:5432->5432/tcp
cs_redis          Up (healthy)    0.0.0.0:6379->6379/tcp
cs_collector      Up              
cs_api            Up              0.0.0.0:8000->8000/tcp
```

> Статус **Up (healthy)** — добре. **Up** без (healthy) — нормально для collector та api.
> Якщо щось **Restarting** — дивись розділ Troubleshooting нижче.

---

## Крок 5 — Перевірка роботи

### 5.1 API

Відкрий у браузері: [http://localhost:8000/docs](http://localhost:8000/docs)

Ти побачиш Swagger UI з усіма ендпоінтами.

Або через термінал:
```bash
curl http://localhost:8000/health
# → {"status":"ok","ts":"2025-..."}
```

### 5.2 Перші дані (через 3–5 хвилин після запуску)

```bash
# Перевірити статус ринків
curl http://localhost:8000/markets

# Переглянути логи колектора — ти побачиш як збираються дані
docker compose logs -f collector

# Приклад нормального логу:
# INFO | [skinport] ✓ 8420 items in 2341ms
# INFO | [dmarket] ✓ 52100 items in 8734ms
# INFO | [spreads] 47 profitable opportunities cached in Redis
```

### 5.3 Перевірити спреди

```bash
# Скільки спредів знайдено
curl http://localhost:8000/spreads | python3 -m json.tool

# Або топ-10 найприбутковіших
curl "http://localhost:8000/spreads?min_profit_pct=5&limit=10"
```

### 5.4 Дашборд

Просто відкрий файл у браузері:
```
# macOS
open dashboard/index.html

# Ubuntu
xdg-open dashboard/index.html

# Windows
start dashboard/index.html

# Або просто перетягни dashboard/index.html у вікно браузера
```

Дашборд автоматично підключиться до `localhost:8000`. 
Поки API не підняв дані — покаже demo режим.

---

## Крок 6 — Опціонально: API ключі для більших лімітів

### CSFloat API Key (рекомендую отримати одразу)

```
1. Зайди на https://csfloat.com
2. Увійди у свій акаунт (або зареєструйся)
3. Профіль → Settings → API Keys → Generate
4. Скопіюй ключ в .env:
   CSFLOAT_API_KEY=твій_ключ_тут
5. Перезапусти collector:
   docker compose restart collector
```

### ShadowPay Token (для повного доступу)

```
1. Відкрий https://shadowpay.com у браузері
2. Увійди в акаунт
3. F12 → Application → Cookies → shadowpay.com
4. Знайди cookie "token" або "session"
5. Скопіюй значення в .env:
   SHADOWPAY_TOKEN=значення_cookie
6. docker compose restart collector
```

---

## Корисні команди

```bash
# Подивитись логи всіх сервісів
docker compose logs -f

# Логи тільки колектора
docker compose logs -f collector

# Логи тільки API
docker compose logs -f api

# Перезапустити один сервіс
docker compose restart collector
docker compose restart api

# Зупинити платформу (дані збережуться)
docker compose down

# Запустити знову
docker compose up -d

# Зайти в ClickHouse і писати SQL запити
docker exec -it cs_clickhouse clickhouse-client \
  --database=cs_arb --user=admin --password=ТВІЙпароль

# Подивитись скільки записів в БД
# (всередині clickhouse-client):
SELECT market, count() as items, max(ts) as last_seen
FROM price_ticks
WHERE ts >= now() - INTERVAL 1 HOUR
GROUP BY market
ORDER BY items DESC;

# Вийти з clickhouse-client
# Ctrl+D або exit

# Повністю видалити все включно з даними (небезпечно!)
docker compose down -v
```

---

## Troubleshooting

### ❌ Container постійно Restarting

```bash
# Подивись детальний лог
docker compose logs collector
docker compose logs api

# Найчастіша причина — неправильний пароль в .env
# Перевір: у паролі немає @ # $ ?
cat .env | grep PASSWORD
```

### ❌ `Error: address already in use` — порт зайнятий

```bash
# Перевір що займає порт 8000
lsof -i :8000          # macOS/Linux
netstat -ano | findstr :8000   # Windows

# Або зміни порт в docker-compose.yml:
# ports:
#   - "8001:8000"   ← міняй ліву цифру
```

### ❌ Немає даних через 10 хвилин

```bash
# Перевір чи collector взагалі запустився
docker compose ps collector

# Подивись помилки
docker compose logs collector | grep ERROR

# Часта причина: ClickHouse ще не готовий
# Просто зачекай 2-3 хвилини і перезапусти
docker compose restart collector
```

### ❌ `No spread data available yet`

Це нормально на старті. Collector повинен зробити хоча б один успішний
збір з 2+ ринків. Зачекай 5-10 хвилин після першого запуску.

```bash
# Подивись чи є дані
docker compose logs collector | grep "items in"
```

### ❌ Dashboard не підключається до API

Перевір що API запущений:
```bash
curl http://localhost:8000/health
```

Якщо не відповідає — API ще стартує (30-60 сек після `docker compose up`).
Онови сторінку дашборду через хвилину.

### ❌ macOS: `Docker daemon is not running`

```
Відкрий Docker Desktop застосунок → зачекай поки стартує → повторно запусти команду
```

### ❌ Windows: `docker: command not found` в PowerShell

```
Закрий і відкрий PowerShell заново після встановлення Docker Desktop.
Або перезавантаж Windows.
```

---

## Перевірка що все працює ✅

Виконай по порядку — якщо всі команди повертають дані, платформа готова:

```bash
# 1. Сервіси запущені
docker compose ps

# 2. API відповідає
curl http://localhost:8000/health

# 3. Ринки підключені
curl http://localhost:8000/markets

# 4. Є спреди в кеші
curl "http://localhost:8000/spreads?limit=3"

# 5. ClickHouse накопичує дані
docker exec -it cs_clickhouse clickhouse-client \
  --database=cs_arb --user=admin --password=ТВІЙпароль \
  --query="SELECT market, count() FROM price_ticks GROUP BY market"
```

---

## Продакшн деплой (коли будеш готовий)

Для запуску на сервері (VPS/Cloud):

```bash
# Рекомендований сервер: Ubuntu 22.04, 4 CPU, 8 GB RAM
# Мінімальний: 2 CPU, 4 GB RAM

# 1. Встанови Docker (як описано вище)
# 2. Скопіюй проект на сервер
scp -r cs-arb/ user@YOUR_SERVER_IP:~/

# 3. На сервері
ssh user@YOUR_SERVER_IP
cd cs-arb
cp .env.example .env
nano .env   # налаштуй паролі + LOG_LEVEL=WARNING

# 4. Запуск
docker compose up -d --build

# 5. Автозапуск після перезавантаження сервера
# (Docker зазвичай стартує автоматично з restart: unless-stopped)
```

**Відкрити доступ ззовні** — додай nginx reverse proxy або просто:
```bash
# Тимчасово (для тесту) — відкрий порт у файрволі
sudo ufw allow 8000/tcp
# API буде доступний на http://YOUR_SERVER_IP:8000
```

---

*Якщо щось не виходить — копіюй текст помилки з `docker compose logs` і питай.*
